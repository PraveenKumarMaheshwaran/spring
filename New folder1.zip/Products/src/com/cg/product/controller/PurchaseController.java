package com.cg.product.controller;

import java.util.ArrayList;

import jdk.nashorn.internal.ir.RuntimeNode.Request;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;

import com.cg.product.bean.Product;
import com.cg.product.bean.Purchase;
import com.cg.product.service.PurchaseService;

@Controller
@RequestMapping("ctrl")
public class PurchaseController {
	@Autowired
	PurchaseService service;
	@RequestMapping("/show")
	public String showdata(@RequestParam("custid")int id,Model model)
	{
		
		String viewname=null;
		ArrayList<Integer> list1=service.viewData();
		if(list1.contains(id))
		{
		ArrayList<Product> list=service.showData();
		if(list.size()!=0)
		{
			viewname="list";
			model.addAttribute("prolist", list);
			model.addAttribute("custid",id);
		}
		}
		else
		{
			viewname="error";
			model.addAttribute("message", "Table cannot be displayed");
		}
		return viewname;
		
	}
	@RequestMapping("cust")
	public String movetoEnter(Model model)
	{
		return "enter";
	}
	@RequestMapping("/add")
	public String addtopurchase(@RequestParam("proId")int id,Model model)
	{
		String viewname;
		Purchase pur=new Purchase();
		pur.setProdId(id);
		int ref=service.addPurchase(id);
		if(ref!=0)
		{
			model.addAttribute("pur", ref);
			viewname="purc";
		}
		else{
			model.addAttribute("message", "unable to add");
			viewname="error";
		}
		return viewname;
	}
	 
    @RequestMapping("/root")
	 public String purchase(Model model,@RequestParam("pId")int prodid,@RequestParam("cid")int custid,@RequestParam("price")int prodprice){
	 model.addAttribute("price",prodprice);
    int purid = service.insert(prodid,custid);
    model.addAttribute("id",purid);
    model.addAttribute("pId",prodid);
    model.addAttribute("cid",custid);
	 return "success";
    }

}
