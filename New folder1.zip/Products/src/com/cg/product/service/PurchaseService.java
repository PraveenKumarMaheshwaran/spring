package com.cg.product.service;

import java.util.ArrayList;

import com.cg.product.bean.Product;
import com.cg.product.bean.Purchase;

public interface PurchaseService {
	ArrayList<Product> showData();
	ArrayList<Integer> viewData();
	public int addPurchase(int pId);
	public int insert(int custid, int prodid);
}
