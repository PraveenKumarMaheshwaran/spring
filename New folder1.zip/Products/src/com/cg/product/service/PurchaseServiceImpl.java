package com.cg.product.service;

import java.util.ArrayList;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;
import org.springframework.stereotype.Service;

import com.cg.product.bean.Product;
import com.cg.product.bean.Purchase;
import com.cg.product.dao.PurchaseDao;

@Service
@Component("service")
public class PurchaseServiceImpl implements PurchaseService {
	@Autowired
	PurchaseDao dao;

	@Override
	public ArrayList<Product> showData() {
		// TODO Auto-generated method stub
		return dao.showData();
	}

	@Override
	public int addPurchase(int pId) {
		// TODO Auto-generated method stub
		return dao.addPurchase(pId);
	}

	@Override
	public ArrayList<Integer> viewData() {
		// TODO Auto-generated method stub
		return dao.viewData();
	}

	@Override
	public int insert(int custid, int prodid) {
		// TODO Auto-generated method stub
		return dao.insert(custid, prodid);
	}

}
