package com.cg.product.dao;

import java.util.ArrayList;

import com.cg.product.bean.Customer;
import com.cg.product.bean.Product;
import com.cg.product.bean.Purchase;

public interface PurchaseDao {
	ArrayList<Product> showData();
	ArrayList<Integer> viewData();
	public Customer seeCustomer(int custId);
	public int insert(int custid, int prodid);
	int  addPurchase(int pId);

}
