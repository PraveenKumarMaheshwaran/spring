package com.cg.product.dao;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;

import org.springframework.stereotype.Component;
import org.springframework.stereotype.Repository;
import org.springframework.ui.Model;

import com.cg.product.bean.Customer;
import com.cg.product.bean.Product;
import com.cg.product.bean.Purchase;
import com.cg.product.util.DBUtil;


@Component("dao")
@Repository
public class PurchaseDaoImpl implements PurchaseDao{
	Connection con;
	public PurchaseDaoImpl()
	{
		con=DBUtil.getConnect();
	}
	


	@Override
	public ArrayList<Product> showData() {
		// TODO Auto-generated method stub
		ArrayList<Product> list=new ArrayList<Product>();
		String sql="SELECT * FROM PRO";
		try{
		Statement st=con.createStatement();
		ResultSet rst=st.executeQuery(sql);
		while(rst.next())
		{
			Product obj=new Product();
			obj.setProdId(rst.getInt(1));
			obj.setProdName(rst.getString(2));
			obj.setProdPrice(rst.getInt(3));
			obj.setProdQuantity(rst.getInt(4));
			list.add(obj);
		}
		}
		catch(SQLException e)
		{
			e.printStackTrace();
		}
		return list;
	}

	@Override
	public int addPurchase(int pId) {
		// TODO Auto-generated method stub
		
		int ref = 0;
		String sql="INSERT INTO PUR VALUES(?)";
		//String sql1="SELECT PUR_SEQ.CURRVAL FROM DUAL";
		try{
		PreparedStatement pst=con.prepareStatement(sql);
		pst.setInt(1, pId);
		int row=pst.executeUpdate();
		if(row==1)
		{
			
		
			
		}

}
		catch(Exception e)
		{
			e.printStackTrace();
		}
		return ref;
		
	}



	@Override
	public Customer seeCustomer(int custId) {
		// TODO Auto-generated method stub
		int result=-1;
		Customer ref=null;
		String sql="SELECT * FROM CUS WHERE CUSTID=?";
		try{
		PreparedStatement pst=con.prepareStatement(sql);
		pst.setInt(1, custId);
		int row=pst.executeUpdate();
		if(row==1)
		{
			
		}
		else{
			result=1;
			
		}
		}
		catch(Exception e)
		{
			e.printStackTrace();
		}
		return ref;
	}



	@Override
	public ArrayList<Integer> viewData() {
		// TODO Auto-generated method stub
		ArrayList<Integer> list1=new ArrayList<Integer>();
		String sql="SELECT CUSTID FROM CUS";
		try{
		PreparedStatement pst=con.prepareStatement(sql);
		ResultSet rst=pst.executeQuery();
		while(rst.next())
		{
			Customer cus=new Customer();
			cus.setCustId(rst.getInt(1));
			list1.add(cus.getCustId());
		}
	}
		catch(SQLException e)
		{
			e.printStackTrace();
		}
		
		return list1;
	}
	public int insert(int custid, int prodid) {
		// TODO Auto-generated method stub
		int purId=0;
		String sql="insert into pur values(pur_seq.nextval,?,?)";
		String sql1="select pur_seq.currval from dual";
		try{
		PreparedStatement pstmt=con.prepareStatement(sql);
		pstmt.setInt(1,custid);
		pstmt.setInt(2,prodid);
	    int res =pstmt.executeUpdate();
		  pstmt=con.prepareStatement(sql1);
		  ResultSet rest =pstmt.executeQuery();
		  if(rest.next()){
		    purId=rest.getInt(1);
		  }
		  }
		catch(SQLException e){
		        e.printStackTrace();
	}
		return purId;
		
	}
}
